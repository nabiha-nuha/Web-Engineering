-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 14, 2022 at 11:38 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_blog_nuha`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE `tbl_category` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`id`, `name`) VALUES
(11, 'Capsule'),
(12, 'Drop'),
(13, 'Inhaler'),
(14, 'Injection'),
(15, 'Liquid'),
(16, 'Tablet'),
(17, 'Suppositories');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_contact`
--

CREATE TABLE `tbl_contact` (
  `id` int(11) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_contact`
--

INSERT INTO `tbl_contact` (`id`, `firstname`, `lastname`, `email`, `body`, `status`, `date`) VALUES
(8, 'Abdur', 'Rahman', 'abdurrahman@gmail.com', 'Hello I am Abdur Rahman. You are doing a great job in this blog. I really appreciate your work. Keep it up.', 0, '2021-11-30 14:09:02'),
(9, 'Rodela', 'Jaman', 'rodela@yahoo.com', 'Hi I am Rodela. I read your posts daily and they are fantastic. I am also an editor in this sector and please let me know if you need an editor in the future. Best regards.', 0, '2021-11-30 14:11:41'),
(10, 'Naim', 'Khan', 'naim@outlook.com', 'Hello Tech Daily. Your site is great for knowing up to date information about technologies. Very good. Keep up the good work.', 1, '2021-11-30 14:19:04');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_footer`
--

CREATE TABLE `tbl_footer` (
  `id` int(11) NOT NULL,
  `note` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_footer`
--

INSERT INTO `tbl_footer` (`id`, `note`) VALUES
(1, 'Nuha Pharma Ltd.');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_page`
--

CREATE TABLE `tbl_page` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `body` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_page`
--

INSERT INTO `tbl_page` (`id`, `name`, `body`) VALUES
(1, 'About Us', '<p><strong>Admin</strong>&nbsp; Nabiha Taieba Nuha</p>\r\n<p><strong>Username:</strong> Nuha</p>\r\n<p><strong>Password:</strong> 000</p>');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_post`
--

CREATE TABLE `tbl_post` (
  `id` int(11) NOT NULL,
  `cat` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `image` varchar(255) NOT NULL,
  `author` varchar(50) NOT NULL,
  `tags` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `userid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_post`
--

INSERT INTO `tbl_post` (`id`, `cat`, `title`, `body`, `image`, `author`, `tags`, `date`, `userid`) VALUES
(29, 17, 'What Exactly Is Alternative Medicine?', '<p><a href=\"https://www.webmd.com/balance/what-is-alternative-medicine\" data-crosslink-type=\"article\" data-metrics-link=\"\">Alternative medicine</a>&nbsp;is a term that describes medical treatments that are used instead of traditional (mainstream) therapies. Some people also refer to it as &ldquo;integrative,&rdquo; or &ldquo;complementary&rdquo; medicine.</p>\r\n<p>More than half of adults in the United States say they use some form of alternative medicine. But exactly what types of therapies are considered alternative? The definition changes as doctors test and move more of them into the mainstream.</p>\r\n<p>This article examines some popular alternative medical treatments and their potential risks and benefits.</p>', 'upload/67d6d1a273.jpg', 'Nuha', 'pharma, medicine, nuha', '2022-11-14 09:48:53', 8),
(31, 14, 'Injection Types & Sites', '<p>When &lsquo;type&rsquo; of injection is mentioned, &lsquo;type&rsquo; usually refers to the body tissue or path by which a medication is injected. The &lsquo;type&rsquo; of injection describes its route of administration.</p>\r\n<p>The four most frequently used types of injection are:</p>\r\n<ol>\r\n<li><span>Intravenous (IV) injections.&nbsp;</span>An IV injection is the fastest way to inject a medication and involves using a syringe to inject a medication directly into a vein. When people talk about receiving medication via IV, however, they are usually talking about an IV infusion or drip, which involves using a pump or gravity to infuse the medication into a vein, rather than a syringe. IV infusions allow a set amount of medication to be administered in a controlled manner over a period of time.</li>\r\n<li><span>Intramuscular (IM) injections.</span>&nbsp;IM injections are given deep into a muscle where the medication is then absorbed quickly by surrounding blood vessels.</li>\r\n<li><span>Subcutaneous (SC) injections.</span>&nbsp;SC injections are injected into the innermost layer of the skin called the subcutis or hypodermis, which is made up of a network of fat and collagen cells. SC injections are also known as &lsquo;subcut&rsquo; or &lsquo;SQ&rsquo; injections. These injections work more slowly than an IV or IM injection because the area does not have such a rich blood supply.</li>\r\n<li><span>Intradermal (ID) injections.</span>&nbsp;ID injections are given directly into the middle layer of the skin called the dermis. This type of injection is absorbed more slowly again than IV, IM or SC injections.</li>\r\n</ol>', 'upload/aec6785ed8.jpg', 'Nuha', 'pharma, injection', '2022-11-14 09:56:58', 8),
(32, 13, 'Asthma inhalers: Which one\'s right for you?', '<p>Asthma inhalers are hand-held, portable devices that deliver medication to your lungs. A variety of asthma inhalers are available to help control asthma symptoms. Finding the right one and using it correctly can help you get the medication you need to prevent or treat asthma attacks.</p>\r\n<div id=\"ad-mobile-top-container\">&nbsp;</div>\r\n<p>To find the best inhaler for you, you need to find a balance between the correct medication and the type of inhaler that suits your needs and your ability to use the inhaler correctly. Training from your doctor or other health care provider is essential for learning to use the device you choose correctly.</p>', 'upload/9c27b21119.jpg', 'Nuha', 'inhaler, pharma, nuha', '2022-11-14 10:03:29', 8);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_slider`
--

CREATE TABLE `tbl_slider` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_slider`
--

INSERT INTO `tbl_slider` (`id`, `title`, `image`) VALUES
(1, 'Intel CPU Factory', 'upload/slider/fe663115d8.jpg'),
(2, 'Apple\'s Iphone 13 Series', 'upload/slider/a871898669.jpg'),
(4, 'Social Media Giants Across The World', 'upload/slider/8f715f489b.jpg'),
(5, 'The Advancements Of AI And Robotics', 'upload/slider/8a3b4ee854.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_social`
--

CREATE TABLE `tbl_social` (
  `id` int(11) NOT NULL,
  `fb` varchar(255) NOT NULL,
  `tw` varchar(255) NOT NULL,
  `ln` varchar(255) NOT NULL,
  `gp` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_social`
--

INSERT INTO `tbl_social` (`id`, `fb`, `tw`, `ln`, `gp`) VALUES
(1, 'http://facebook.com', 'http://twitter.com', 'http://linkedin.com', 'http://google.com');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_theme`
--

CREATE TABLE `tbl_theme` (
  `id` int(11) NOT NULL,
  `theme` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_theme`
--

INSERT INTO `tbl_theme` (`id`, `theme`) VALUES
(1, 'blue');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(32) NOT NULL,
  `email` varchar(255) NOT NULL,
  `details` text NOT NULL,
  `role` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `name`, `username`, `password`, `email`, `details`, `role`) VALUES
(8, 'Nuha', 'Nuha', '000', 'nuha@gmail.com', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `title_slogan`
--

CREATE TABLE `title_slogan` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `slogan` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `title_slogan`
--

INSERT INTO `title_slogan` (`id`, `title`, `slogan`, `logo`) VALUES
(1, 'Nuha Pharma Ltd.', 'Your betterment is our concern', 'upload/logo.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_contact`
--
ALTER TABLE `tbl_contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_footer`
--
ALTER TABLE `tbl_footer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_page`
--
ALTER TABLE `tbl_page`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_post`
--
ALTER TABLE `tbl_post`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_slider`
--
ALTER TABLE `tbl_slider`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_social`
--
ALTER TABLE `tbl_social`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_theme`
--
ALTER TABLE `tbl_theme`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `title_slogan`
--
ALTER TABLE `title_slogan`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_category`
--
ALTER TABLE `tbl_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `tbl_contact`
--
ALTER TABLE `tbl_contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tbl_footer`
--
ALTER TABLE `tbl_footer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_page`
--
ALTER TABLE `tbl_page`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_post`
--
ALTER TABLE `tbl_post`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `tbl_slider`
--
ALTER TABLE `tbl_slider`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_social`
--
ALTER TABLE `tbl_social`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_theme`
--
ALTER TABLE `tbl_theme`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `title_slogan`
--
ALTER TABLE `title_slogan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
